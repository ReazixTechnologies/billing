# Reazix Billing - Windows updater.
#
# Pulls the latest release ZIP from billing.reazix.com, extracts _system/ over
# the existing one, re-runs npm install. Data folder is preserved.
#
# Design decisions:
#   * Data folder never touched - user's invoices survive updates
#   * We fetch by tag_name from the release file on billing.reazix.com so users always get
#     the latest published release, not a random dev commit
#   * Pre-update, we snapshot data/ to a timestamped backup as a
#     safety net - even though we don't touch data, hardware faults
#     during rmdir could corrupt state
#   * v1.10.75 - -InstallTo <installed app folder>: run from a newly
#     extracted ZIP, this updates THAT install from the files in this ZIP,
#     with no download. It works offline and does not depend on the older
#     copy's own updater. The launcher uses it when it finds the app already
#     installed elsewhere, instead of installing a second copy.

param([string]$InstallTo = '')

$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'Reazix Billing - Update'

# When the app runs this (Update button), nobody can press Enter: the script
# has no keyboard. Waiting for Enter there hung the update forever and the
# app kept showing "Updating..." with the work already done. Only wait when
# a person opened this script in a window.
function Wait-Close {
  if (-not [Console]::IsInputRedirected) { Read-Host '  Press Enter to close' | Out-Null }
}

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SystemDir = $ScriptDir
$RootDir   = Split-Path -Parent $ScriptDir
$FromFolder = ''
if ($InstallTo) {
  $FromFolder = $RootDir
  $RootDir   = $InstallTo.TrimEnd('\')
  $SystemDir = Join-Path $RootDir '_system'
  if (($RootDir -eq $FromFolder.TrimEnd('\')) -or -not (Test-Path -LiteralPath (Join-Path $SystemDir 'server.js'))) {
    Write-Host "  ERROR: no installed copy of the app in $RootDir." -ForegroundColor Red
    Wait-Close
    exit 1
  }
}

Write-Host ''
Write-Host '  ============================================================'
Write-Host '   Reazix Billing Software - Update'
Write-Host '  ============================================================'
Write-Host ''

# --- Step 1: Belt-and-braces backup of data folder BEFORE anything ---
$dataDir = Join-Path $SystemDir 'data'
if (Test-Path $dataDir) {
  $backupsHome = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Reazix Billing Backups'
  if (-not (Test-Path $backupsHome)) { New-Item -ItemType Directory -Path $backupsHome | Out-Null }
  $stamp = Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'
  $preUpdateBackup = Join-Path $backupsHome "pre-update-$stamp.zip"
  Write-Host "  Backing up your data to $preUpdateBackup ..."
  Compress-Archive -Path "$dataDir\*" -DestinationPath $preUpdateBackup -Force
}

$tmp = $null
if ($FromFolder) {
  Write-Host "  Updating $RootDir"
  Write-Host "  from the files in $FromFolder (no download needed)..."
  $sourceRoot = $FromFolder
  $newSystem  = Join-Path $FromFolder '_system'
} else {
# --- Step 2: Find latest release ---
Write-Host '  Checking for the latest release...'
try {
  $api = Invoke-RestMethod -Uri 'https://billing.reazix.com/updates/latest.json' -Headers @{ 'User-Agent' = 'ReazixBilling-Updater' }
  $tag = $api.tag_name
  $zipAsset = $api.assets | Where-Object { $_.name -like '*.zip' } | Select-Object -First 1
  $zipUrl = if ($zipAsset) { $zipAsset.browser_download_url } else { $null }
  Write-Host "  Latest: $tag"
} catch {
  Write-Host "  ERROR: could not reach billing.reazix.com. Are you online?" -ForegroundColor Red
  Wait-Close
  exit 1
}

# Only a signed release ZIP is installed (no unsigned fallback).
if (-not $zipUrl -or -not $zipAsset.signature) {
  Write-Host "  ERROR: release $tag has no signed ZIP yet. Try again later. Nothing was changed." -ForegroundColor Red
  Wait-Close
  exit 1
}

# --- Step 3: Download + extract to a staging folder ---
$tmp = Join-Path $env:TEMP "fgstbill-update-$([Guid]::NewGuid().ToString('N').Substring(0,8))"
New-Item -ItemType Directory -Path $tmp | Out-Null
$zipPath = Join-Path $tmp 'update.zip'
Write-Host '  Downloading update...'
Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing

# The ZIP must be signed by Reazix. Checked with verify-update.cjs from THIS
# installed copy, so a ZIP swapped on a hacked website is never installed.
. (Join-Path $ScriptDir 'ensure-node.ps1')
$verifyNode = Get-NodeCandidates | Select-Object -First 1
$verifier = Join-Path $ScriptDir 'verify-update.cjs'
if (-not $verifyNode -or -not (Test-Path -LiteralPath $verifier)) {
  Write-Host '  ERROR: could not check the update signature (Node.js or verify-update.cjs missing). Nothing was changed.' -ForegroundColor Red
  Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
  Wait-Close
  exit 1
}
& $verifyNode $verifier $zipPath $tag $zipAsset.signature
if ($LASTEXITCODE -ne 0) {
  Write-Host '  ERROR: the update was refused because it is not signed by Reazix. Nothing was changed.' -ForegroundColor Red
  Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
  Wait-Close
  exit 1
}

Write-Host '  Extracting...'
# v1.10.83 - the ZIP now carries about 12,000 package files. Expand-Archive
# takes minutes over that many; .NET's own unzip takes seconds.
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $tmp)

# The extract may contain either the pretty release structure
# (root has Reazix Billing - WINDOWS.hta + _system/) or the source zipball
# (root has a single top-level folder).
$extracted = Get-ChildItem -Path $tmp -Directory | Select-Object -First 1
$candidateSystem = Join-Path $extracted.FullName '_system'
if (Test-Path $candidateSystem) {
  $sourceRoot = $extracted.FullName
  $newSystem  = $candidateSystem
} else {
  # Zipball layout - treat the extracted folder itself as the "new _system"
  $sourceRoot = $extracted.FullName
  $newSystem  = $extracted.FullName
}
}

# --- Step 4: Copy everything EXCEPT data/ over the current _system/ ---
Write-Host '  Applying update (your data folder is untouched)...'
# Never replaced: the books, saved PDFs, the trash, Node.js and installed
# packages. (A folder the user extracted and opened may hold its own empty
# copies of these; they must not land on top of the real ones.)
$keep = @('data', 'node_modules', 'node', 'Saved Invoices', 'Trash')
# v1.10.83 - a release that ships its packages replaces node_modules too, and
# then nothing needs npm. Older packages (or the source zipball) still do.
$shipped = Test-Path -LiteralPath (Join-Path $newSystem 'node_modules\express\package.json')
if ($shipped) { $keep = $keep | Where-Object { $_ -ne 'node_modules' } }
Get-ChildItem -Path $newSystem -Force | Where-Object { $keep -notcontains $_.Name } | ForEach-Object {
  $dest = Join-Path $SystemDir $_.Name
  if (Test-Path $dest) { Remove-Item $dest -Recurse -Force -ErrorAction SilentlyContinue }
  Copy-Item -Path $_.FullName -Destination $dest -Recurse -Force
}
# If the new release ships new launcher/HTA files at root, refresh those too
Get-ChildItem -Path $sourceRoot -File | Where-Object { $_.Extension -match '\.(hta|command|sh)$' -or $_.Name -match '^Reazix Billing' } | ForEach-Object {
  Copy-Item -Path $_.FullName -Destination (Join-Path $RootDir $_.Name) -Force
}
# v1.10.83 - a clean update: files an older version had and this one does not
# are removed. Only for a full release package (never a source zipball, which
# has no built app), and never the books, saved PDFs, the bin or Node.js.
if ($shipped) {
  $shippedNames = @(Get-ChildItem -Path $newSystem -Force | ForEach-Object { $_.Name })
  $protected = @('data', 'Saved Invoices', 'Trash', 'node', 'node-dir.txt')
  Get-ChildItem -Path $SystemDir -Force | Where-Object {
    $shippedNames -notcontains $_.Name -and $protected -notcontains $_.Name -and -not $_.Name.StartsWith('.')
  } | ForEach-Object { Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue }
  $rootNames = @(Get-ChildItem -Path $sourceRoot -File | ForEach-Object { $_.Name })
  Get-ChildItem -Path $RootDir -File | Where-Object {
    ($_.Name -like 'Reazix Billing - *' -or $_.Name -eq 'READ ME FIRST.txt') -and $rootNames -notcontains $_.Name
  } | ForEach-Object { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue }
}

# --- Step 5: Reinstall dependencies (safest - new package.json may add packages) ---
if (-not $shipped) { Write-Host '  Re-installing dependencies...' }
Push-Location $SystemDir
# v1.10.69 - Node.js may live inside the app folder (see install-windows.ps1).
# v1.10.81 (#109) - and it must be new enough: an old Node.js on PATH (6.10)
# brought npm 3, which broke the install, and this still said "complete".
. (Join-Path $SystemDir 'ensure-node.ps1')
$npmOk = $false
if ($shipped) {
  # Only Node.js itself may still be needed (fetched once if this PC has none).
  $npmOk = [bool](Use-GoodNode)
} elseif ((Use-GoodNode) -and (Test-InstallReady)) {
  if ($script:NodeWasFetched -or (Test-PackagesBroken)) { Reset-Packages }
  npm install --omit=dev --no-audit --no-fund --loglevel=error
  $npmOk = ($LASTEXITCODE -eq 0)
  if (-not $npmOk) { Show-InstallHelp }
}
Pop-Location
if (-not $npmOk) {
  if ($tmp) { Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue }
  Write-Host ''
  Write-Host '  The new version is in place, but it is not ready to run yet (see above).' -ForegroundColor Red
  Write-Host '  Your data is safe (a backup was made above). Fix the problem shown,'
  Write-Host '  then open the app from its icon: it finishes the install by itself.'
  Wait-Close
  exit 1
}

# --- Cleanup ---
if ($tmp) { Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue }

Write-Host ''
Write-Host '  [OK] Update complete!' -ForegroundColor Green
Write-Host '  Restart the app (Stop Server -> Open App) to run the new version.'
Write-Host ''
Wait-Close
