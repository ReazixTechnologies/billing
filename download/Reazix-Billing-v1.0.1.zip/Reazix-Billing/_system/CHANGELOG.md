# Changelog

All notable changes to **Reazix Billing Software** are listed here.

---

## [1.0.1] - 2026-11-09

**Product key activation.**

### How to update

**Current version:** 1.0.0  →  **New version:** 1.0.1

Click **Update** in the app's menu. Your invoices and settings are kept.
After the update the app asks once for your product key.

### Changed
- **Product key:** the app now opens with a product key from Reazix, entered
  once and valid for life. The first screen shows this PC's code: send it to
  Reazix and paste the key you get back. One key works on one PC.
- **Shop details from the key:** a key can carry the business name, GSTIN and
  address. They fill the invoice header by themselves and stay fixed.
- **More counters:** a shop's second (third...) counter gets its own key, the
  same header, and its own invoice numbers (C2/..., C3/...), so two counters
  never print the same number.

---

## [1.0.0] - 2026-11-06

**The first release of Reazix Billing.**

### How to update

**Current version:** none  →  **New version:** 1.0.0

This is the first version, so there is nothing to update. Later versions
arrive through **Update** in the app's menu, or by downloading
`Reazix-Billing.zip` from billing.reazix.com and opening it over your current
folder. Your invoices and settings are kept.

### Included
- **GST invoicing:** tax invoices, proforma, credit notes, bill of supply and
  delivery challans, with CGST / SGST / IGST worked out from the place of supply.
- **GST returns:** GSTR-1 and GSTR-3B JSON exports, GSTR-2B reconciliation,
  e-Way Bill and e-invoice JSON.
- **Barcode scanning:** give each product a barcode, then scan it on an
  invoice with a USB or Bluetooth scanner. Each scan adds the product, or one
  more of it.
- **Stock and purchases:** products, purchase bills and orders, stock reports
  and manufacturing.
- **Money:** payments, receipts, expenses, cash book, TDS / TCS reports and
  income tax helpers.
- **Works offline:** your data stays on your computer, with daily backups and
  an optional PIN lock.

---
